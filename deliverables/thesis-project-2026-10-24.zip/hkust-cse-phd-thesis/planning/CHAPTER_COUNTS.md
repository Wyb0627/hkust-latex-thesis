# Chapter word and page counts

Entry: `main.tex`; PDF: `thesis.pdf`. Counts use TeXcount, including prose in the eight chapter files, headings and captions as separate columns. Numeric and textual table cells, equations, bibliography, front matter and comments are excluded from the narrative column. Table captions from included files are assigned to their parent chapter. TeXcount can classify longtable cell labels as prose; these are deliberately excluded from the narrative budget. Page counts come from the actual PDF bookmarks and page labels, not an estimated words-to-pages conversion.

| Chapter | Narrative | Headings | Captions | Total non-cell English words | Printed pages | Pages |
|---|---:|---:|---:|---:|---|---:|
| 1. Introduction | 2,817 | 58 | 36 | 2,911 | 1–9 | 9 |
| 2. Background and Related Work | 3,975 | 46 | 83 | 4,104 | 10–21 | 12 |
| 3. Knowledge-enriched Table Understanding with KGLink | 4,579 | 88 | 234 | 4,901 | 22–40 | 19 |
| 4. Adaptive Graph Retrieval for Dynamic Classification with GORAG | 4,952 | 73 | 333 | 5,358 | 41–59 | 19 |
| 5. Connected Evidence Selection for Language Models with AGRAG | 4,849 | 90 | 322 | 5,261 | 60–82 | 23 |
| 6. Semantic Graph Matching for Multimodal Reasoning with MGRAG | 6,064 | 116 | 381 | 6,561 | 83–109 | 27 |
| 7. Discussion | 1,962 | 30 | 18 | 2,010 | 110–115 | 6 |
| 8. Conclusion and Future Directions | 825 | 20 | 0 | 845 | 116–118 | 3 |
| **Total** | **30,023** | **521** | **1407** | **31,951** | **1–118** | **118** |

Abstract: 261 English words (limit 300). PDF: 137 pages, comprising 14 preliminary pages, 118 body pages and 5 reference pages. The body narrative is at the lower end of the 30,000–38,000 writing range; no repetitive background was added to reach the midpoint.

PDF SHA-256: `95cac4f970108cfdd2d3c49ddfa71e9f5685042e1995cd789ce6835c9b509c7f`. Machine-readable counts: `planning/qa/final/chapter-counts.json`; raw counter output: `planning/qa/texcount.txt`.
