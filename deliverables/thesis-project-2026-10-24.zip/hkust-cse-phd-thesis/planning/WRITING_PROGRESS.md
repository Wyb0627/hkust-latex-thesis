# Thesis writing progress and handoff

Updated: 2026-10-24 (Asia/Shanghai). **Complete eight-chapter English manuscript delivered for author/supervisor review; signature/institutional items remain with the author.** This file supersedes earlier checkpoint descriptions; detailed research audits retain their original snapshot dates/counts.

## Entry, template and deliverable

- Title: **Structural Augmented Reasoning for Language Models**; author Yubo Wang.
- Build: `make`; entry `main.tex`; output `thesis.pdf` (also `main.pdf`). XeLaTeX + Biber + latexmk, shell escape disabled, explicit project-local chapter inputs.
- Template: HKFoggyU v0.11.6, release commit `1a9230d`, vendored class/source/license under `template/hkust-thesis-v0.11.6/`. Class internal version predates the release tag and is preserved unchanged. Original MPhil example is backed up under `legacy/mars-2010/`.
- Final PDF: **137 pages**, **30,023 narrative words**, **31,951 with headings/captions**, **261-word abstract**. Final SHA-256 `95cac4f970108cfdd2d3c49ddfa71e9f5685042e1995cd789ce6835c9b509c7f`. Counts/ranges in `CHAPTER_COUNTS.md`.

## Chapter state

| Chapter | File | State |
|---|---|---|
| 1 | `chapter/ch01-introduction.tex` | Complete; 2,817 narrative words, 9 pages |
| 2 | `chapter/ch02-background.tex` | Complete; 3,975 narrative words, 12 pages |
| 3 | `chapter/ch03-kglink.tex` | Complete; 4,579 narrative words, 19 pages |
| 4 | `chapter/ch04-gorag.tex` | Complete; 4,952 narrative words, 19 pages |
| 5 | `chapter/ch05-agrag.tex` | Complete; 4,849 narrative words, 23 pages |
| 6 | `chapter/ch06-mgrag.tex` | Complete; 6,064 narrative words, 27 pages |
| 7 | `chapter/ch07-discussion.tex` | Complete; 1,962 narrative words, 6 pages |
| 8 | `chapter/ch08-conclusion.tex` | Complete; 825 narrative words, 3 pages |

Front matter: `chapter/front-abstract.tex`, `chapter/front-acknowledgements.tex`, metadata in `main.tex`. The CIKM HyperKG/FormerGNN study is a separate Background §2.6, about960 prose words. MGRAG retains query-aware construction, semantic paths and graph-aware recomputation. CMI-Mem and ClinicalAgents are excluded from core contributions. No common implementation or algorithmic dependency has been invented.

## Evidence accepted

- Followed `THESIS_WRITING_PLAN.md`, `HKUST_PHD_REFERENCE_REVIEW.md`, `SOURCE_MAP.md`, roots/inventory and proposal/reference roles; no new scope plan replaced them.
- MGRAG uses the directly retrieved PVLDB publisher PDF. KGLink/GORAG/HyperKG use the author's confirmed publication-equivalent arXiv versions, identified as such rather than as direct publisher downloads.
- **AGRAG uses the local complete ICDE2026.pdf and active source, explicitly selected by the author.** The incomplete arXiv main/data tables are not claimed verified. A portable copy is `planning/published/agrag-local-complete.pdf`.
- 1,765 adopted numeric/missing entries checked across the five works; 27 original graphic hashes match; methods/formulas/key results have source locators. Detailed record: `EVIDENCE_SUMMARY.md` and `verification-*.md`.
- Main-text precedence for KGLink/GORAG/AGRAG conflicts is author-confirmed. Conflicting supplementary monotonicity/global-approximation claims are not promoted to thesis guarantees. MGRAG b remains symbolic because the exact experimental budget was not established.
- 105 bibliography records merge into74 works with31 key aliases. Primary metadata corrections are logged. No unresolved citations or repeated reference entries remain.

## Decisions confirmed by the author

December2026 submission; tentative27November2026 defense; Prof.Lei Chen, Chair Professor, supervisor. The author approved the personal leadership statement with discussions/collaboration by Dr.Haoyang Li, Dr.Hao Xin and Dr.Shimin Di. A brief acknowledgment draft is authorized. These statements do not allocate unconfirmed individual tasks.

## Latest build and checks

Successful clean auxiliary build and final `make`; no undefined references/citations, duplicate labels, missing assets/glyphs or overfull boxes; Biber warning-free. Actual137-page PDF inspected through all-page contact sheets and detailed figure/table/formula/front-matter renders. MGRAG short-table splitting, displaced AGRAG heatmaps and local orphan lines were repaired. `FINAL_QA.md` records evidence, limitations and final artifact hash. `STYLE_AUDIT.md` contains the required nine-column audit, applied edits and phrase counts. Original embedded portrait thumbnails below300ppi are identified explicitly; no artificial upsampling or figure replacement was used.

## Remaining information and directly executable next steps

1. Obtain the real department-head name/title and signature dates/signatures; update `main.tex` only from confirmed information. Keep defense date distinct from signature date.
2. Resolve the official sample's title-page i display contradiction with FYTGS/CSE. Current output counts/displays i following its visible sample. FYTGS webpage returned403; do not claim fresh page verification.
3. If supplied, use original experiment configurations/logs to resolve the MGRAG fixed recomputation budget. Do not infer it from a code default.
4. Author/supervisor review can now proceed on the complete PDF. Refine personal acknowledgments if desired; arrange required departmental/iThenticate steps. All concrete author actions are in `AUTHOR_ACTIONS.md`.
5. After any content/metadata change run `make`, `make counts`, regenerate `scripts/inspect_thesis_pdf.py` with a Python environment containing pypdf/pdfplumber/Pillow, then `scripts/report_thesis_counts.py`. Inspect affected PDF pages; refresh hashes in this record and QA before labeling a newer PDF checked.

No new session is required to understand or continue the project. There is no outstanding parallel edit ownership: main controls integration; agents' source/PDF reports are saved in planning. Ordinary context compression is not completion of author review or institutional approval.

## Delivery package checkpoint

Portable archive: `deliverables/thesis-project-2026-10-24.zip`; per-file hashes `deliverables/package-manifest.json`; external checksums `deliverables/SHA256SUMS`. Independent extraction and fresh `make` passed,137pages with identical PDF text. The compact package excludes legacy examples and large QA render images; the full workspace retains them.
