# HKUST Thesis

[![LICENSE](https://img.shields.io/github/license/HKFoggyU/hkust-thesis)](https://www.latex-project.org/lppl/lppl-1-3c/)
[![STARS](https://img.shields.io/github/stars/HKFoggyU/hkust-thesis)](https://github.com/HKFoggyU/hkust-thesis/stargazers)
[![TEST](https://github.com/HKFoggyU/hkust-thesis/actions/workflows/test.yml/badge.svg)](https://github.com/HKFoggyU/hkust-thesis/actions)
[![RELEASE](https://github.com/HKFoggyU/hkust-thesis/actions/workflows/release.yml/badge.svg)](https://github.com/HKFoggyU/hkust-thesis/releases)

[中文说明](README_CN.md)

HKUST Thesis template for RPG students implemented with LaTeX3.

> Check its Typst counterpart: [hkust-thesis-typst](https://github.com/HKFoggyU/hkust-thesis-typst).

## Getting started

**Please read the [PDF documentation](https://github.com/HKFoggyU/hkust-thesis/releases/latest/download/hkustthesis.pdf)** carefully before trial.<br/>
**Please read the [PDF documentation](https://github.com/HKFoggyU/hkust-thesis/releases/latest/download/hkustthesis.pdf)** carefully before trial.<br/>
**Please read the [PDF documentation](https://github.com/HKFoggyU/hkust-thesis/releases/latest/download/hkustthesis.pdf)** carefully before trial.

### Online

Attention: Limited by Overleaf Free Plan, I cannot update this project on Overleaf anymore. Please try GitHub Release for latest update and/or TeXPage.

Try this template on [TeXPage](https://www.texpage.com/template/373737be-dc33-4df2-a7d0-a512a92715ef) (or [Overleaf](https://www.overleaf.com/latex/templates/hkustthesis/mstwvckmhmjg), but outdated). Remember to change the `Compiler` to `XeLaTeX` in the settings, otherwise it may fail to compile.
- for TeXPage, via the top right `Setting` button
- for Overleaf, via the top left `Menu` button

### Local

Alternatively, you can download the [release zip file](https://github.com/HKFoggyU/hkust-thesis/releases/latest) and try it on your local machine.

## Contributions

If you find any problems or have any suggestions, please file an issue or PR.

## Disclaimer

FYTGS doesn't provide any template for thesis submission. They only emphasize that the submitted PDF file should meet the requirements in the [RPG Handbook](https://fytgs.hkust.edu.hk/academics/Academic-Regulations-and-Requirements/Handbook-for-Research-Postgraduate-Studies/guidelines-thesis-preparation).

This template has tried its best to follow the above requirements in the RPG Handbook and also the formatting instructions of the sample pages ([MPhil](https://fytgs.hkust.edu.hk/system/files/thesis_sample_page_mphil.pdf)/[PhD](https://fytgs.hkust.edu.hk/system/files/thesis_sample_page_phd.pdf)/[DBA](https://fytgs.hkust.edu.hk/system/files/thesis_sample_page_dba.pdf)) provided by the RPG Handbook. However, this template takes no responsibility for any potential inconsistency.

## License

LaTeX Project Public License (version 1.3c)

## Acknowledgements

This project is modified from the [`` NJUThesis ``](https://github.com/nju-lug/NJUThesis) project with the help from [NJU-LUG](https://github.com/nju-lug).

